// language: Java 21  file: Fly.java
// Polar bypass: ground-spoof packet every SPOOF_INTERVAL ticks resets the
// server's Y-history window, preventing cumulative-flight-distance flagging.
// A tiny downward nudge (GRAVITY_STUB) keeps the gravity-check alive.
package dev.ghost.client.module.movement;

import dev.ghost.client.module.Module;
import dev.ghost.client.util.MovementUtil;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public class Fly extends Module {

    public static double  SPEED          = 0.55;
    public static double  VERT_SPEED     = 0.35;
    public static int     SPOOF_INTERVAL = 10;   // ticks between fake ground packets
    public static boolean GLIDE_MODE     = false; // true = slower, harder to detect

    private int spoofTimer = 0;

    public Fly() {
        super("Fly", Category.MOVEMENT, GLFW.GLFW_KEY_F, "Polar-bypass fly");
    }

    @Override
    public void onEnable() {
        if (nullCheck()) {
            mc.player.getAbilities().flying = false;
        }
        spoofTimer = 0;
    }

    @Override
    public void onDisable() {
        if (nullCheck()) {
            mc.player.getAbilities().flying = false;
            mc.player.setVelocity(mc.player.getVelocity().x, 0, mc.player.getVelocity().z);
        }
    }

    @Override
    public void onTick() {
        if (!nullCheck()) return;

        // Cancel vanilla gravity
        mc.player.fallDistance = 0f;
        Vec3d v = mc.player.getVelocity();

        double targetY = -0.01; // gravity stub

        if (mc.options.jumpKey.isPressed()) {
            targetY = GLIDE_MODE ? Math.min(v.y + 0.04, VERT_SPEED * 0.6) : VERT_SPEED;
        } else if (mc.options.sneakKey.isPressed()) {
            targetY = GLIDE_MODE ? Math.max(v.y - 0.04, -VERT_SPEED * 0.6) : -VERT_SPEED;
        }

        double horizSpeed = GLIDE_MODE ? SPEED * 0.5 : SPEED;
        MovementUtil.setSpeed(horizSpeed);
        mc.player.setVelocity(mc.player.getVelocity().x, targetY, mc.player.getVelocity().z);

        // Ground spoof — resets server Y-history
        if (++spoofTimer >= SPOOF_INTERVAL) {
            spoofTimer = 0;
            mc.getNetworkHandler().sendPacket(
                new PlayerMoveC2SPacket.OnGroundOnly(true));
        }
    }
}
