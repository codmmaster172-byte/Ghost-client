// language: Java 21  file: Module.java  target: Fabric 1.21.4
package dev.ghost.client.module;

import net.minecraft.client.MinecraftClient;

public abstract class Module {

    public enum Category { COMBAT, MOVEMENT, RENDER, MISC }

    protected static final MinecraftClient mc = MinecraftClient.getInstance();

    private final String   name;
    private final Category category;
    private int            key;       // GLFW key code, 0 = none
    private boolean        enabled;
    private String         description;

    public Module(String name, Category category, int key, String description) {
        this.name        = name;
        this.category    = category;
        this.key         = key;
        this.description = description;
    }

    public void onTick()                {}
    public void onRender()              {}
    public void onEnable()              {}
    public void onDisable()             {}

    public final void toggle() {
        enabled = !enabled;
        if (enabled) onEnable(); else onDisable();
    }

    public boolean isEnabled()              { return enabled; }
    public void    setEnabled(boolean v)    { if (v != enabled) toggle(); }
    public String  getName()                { return name; }
    public Category getCategory()           { return category; }
    public int     getKey()                 { return key; }
    public void    setKey(int k)            { key = k; }
    public String  getDescription()         { return description; }

    protected boolean nullCheck() {
        return mc.player != null && mc.world != null;
    }
}
