// language: Java 21  file: MixinLivingEntity.java
// Cancels the fall-damage call on the client side when NoFall is active.
package dev.ghost.client.mixin;

import dev.ghost.client.GhostClient;
import dev.ghost.client.module.movement.NoFall;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LivingEntity.class)
public class MixinLivingEntity {

    @Inject(method = "handleFallDamage", at = @At("HEAD"), cancellable = true)
    private void onFallDamage(float fallDistance, float damageMultiplier,
                               DamageSource source, CallbackInfo ci) {
        if (GhostClient.moduleManager == null) return;
        NoFall nf = GhostClient.moduleManager.getModule(NoFall.class);
        if (nf != null && nf.isEnabled()) {
            ci.cancel();
        }
    }
}
