// language: Java 21  file: ResetVL.java
// Polar tracks violations per check-category.  This module:
//  1. Briefly pauses all movement modification (lets velocity bleed to zero)
//  2. Sends 20 perfectly-clean OnGround packets at normal cadence
//  3. After the sequence, auto-disables itself
// Run it when you see a "Polar detected" chat message — clears combat and
// movement VLs before they hit the kick threshold.
package dev.ghost.client.module.misc;

import dev.ghost.client.GhostClient;
import dev.ghost.client.module.Module;
import dev.ghost.client.module.movement.Fly;
import dev.ghost.client.module.movement.Speed;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class ResetVL extends Module {

    private static final int CLEAN_TICKS = 20; // one full second of clean packets
    private int tickCount = 0;
    private boolean wasFlyEnabled, wasSpeedEnabled;

    public ResetVL() {
        super("ResetVL", Category.MISC, GLFW.GLFW_KEY_UNKNOWN, "Drain Polar violation levels");
    }

    @Override
    public void onEnable() {
        if (!nullCheck()) { setEnabled(false); return; }

        tickCount = 0;

        // Disable movement modules so packets are clean during reset
        Fly   fly   = GhostClient.moduleManager.getModule(Fly.class);
        Speed speed = GhostClient.moduleManager.getModule(Speed.class);

        wasFlyEnabled   = fly   != null && fly.isEnabled();
        wasSpeedEnabled = speed != null && speed.isEnabled();

        if (wasFlyEnabled)   fly.setEnabled(false);
        if (wasSpeedEnabled) speed.setEnabled(false);

        mc.player.sendMessage(Text.literal("§7[Ghost] §fResetting VL..."), true);
    }

    @Override
    public void onTick() {
        if (!nullCheck()) { setEnabled(false); return; }

        tickCount++;

        // Send a clean, honest ground packet each tick
        mc.getNetworkHandler().sendPacket(
            new PlayerMoveC2SPacket.Full(
                mc.player.getX(),
                mc.player.getY(),
                mc.player.getZ(),
                mc.player.getYaw(),
                mc.player.getPitch(),
                mc.player.isOnGround()));

        if (tickCount >= CLEAN_TICKS) {
            // Restore movement modules
            Fly   fly   = GhostClient.moduleManager.getModule(Fly.class);
            Speed speed = GhostClient.moduleManager.getModule(Speed.class);

            if (wasFlyEnabled   && fly   != null) fly.setEnabled(true);
            if (wasSpeedEnabled && speed != null) speed.setEnabled(true);

            mc.player.sendMessage(Text.literal("§7[Ghost] §aVL reset done"), true);
            setEnabled(false); // auto-disable after one cycle
        }
    }
}
