// language: Java 21  file: Timer.java
// Writes MinecraftClient's tickDelta multiplier via reflection.
// 1.08× is safe under Polar's PacketFrequency threshold (~1.15×).
// In 1.21.4 the field is "tickManager" → TickManager.tickRate.
// We patch tickRate directly on the TickManager instance.
package dev.ghost.client.module.misc;

import dev.ghost.client.module.Module;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

import java.lang.reflect.Field;

public class Timer extends Module {

    private static final float SPEED  = 1.08f;
    private static final float NORMAL = 20.0f; // TickManager uses ticks/second (20 = normal)

    private Field tickRateField;
    private Object tickManager;

    public Timer() {
        super("Timer", Category.MISC, GLFW.GLFW_KEY_UNKNOWN, "Subtle tick-rate boost");
        resolveField();
    }

    @Override public void onEnable()  { setRate(NORMAL * SPEED); }
    @Override public void onDisable() { setRate(NORMAL); }

    private void resolveField() {
        // Fabric 1.21.4: MinecraftClient has a field 'tickManager' of type TickManager
        // TickManager has 'tickRate' float field (Yarn: tickRate)
        try {
            // Find the TickManager field on MinecraftClient
            for (Field f : MinecraftClient.class.getDeclaredFields()) {
                if (f.getType().getSimpleName().equals("TickManager")) {
                    f.setAccessible(true);
                    tickManager = f.get(mc);
                    break;
                }
            }
            if (tickManager == null) return;
            // Find the tickRate float on TickManager
            for (Field f : tickManager.getClass().getDeclaredFields()) {
                if (f.getType() == float.class) {
                    f.setAccessible(true);
                    tickRateField = f;
                    break;
                }
            }
        } catch (Exception e) {
            // Field not found — timer no-ops gracefully
        }
    }

    private void setRate(float rate) {
        if (tickRateField == null || tickManager == null) return;
        try {
            tickRateField.setFloat(tickManager, rate);
        } catch (Exception ignored) {}
    }
}
