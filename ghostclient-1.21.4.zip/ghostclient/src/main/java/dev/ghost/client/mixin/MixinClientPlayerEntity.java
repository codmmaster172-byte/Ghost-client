// language: Java 21  file: MixinClientPlayerEntity.java
// Injects at the head of ClientPlayerEntity.tickMovement() so movement
// modules (Fly, Speed, NoFall) can modify velocity BEFORE the physics step
// and before the position packet is constructed and queued.
package dev.ghost.client.mixin;

import dev.ghost.client.GhostClient;
import dev.ghost.client.module.movement.NoFall;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerEntity.class)
public class MixinClientPlayerEntity {

    @Inject(method = "tickMovement", at = @At("HEAD"))
    private void onTickMovementHead(CallbackInfo ci) {
        if (GhostClient.moduleManager == null) return;
        // NoFall resets fallDistance here so the vanilla physics step sees 0
        NoFall noFall = GhostClient.moduleManager.getModule(NoFall.class);
        if (noFall != null && noFall.isEnabled()) {
            ((ClientPlayerEntity)(Object)this).fallDistance = 0f;
        }
    }
}
