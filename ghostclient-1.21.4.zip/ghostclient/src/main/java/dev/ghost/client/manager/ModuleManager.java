// language: Java 21  file: ModuleManager.java
package dev.ghost.client.manager;

import dev.ghost.client.module.Module;
import dev.ghost.client.module.combat.AntiKB;
import dev.ghost.client.module.combat.KillAura;
import dev.ghost.client.module.misc.ResetVL;
import dev.ghost.client.module.misc.Timer;
import dev.ghost.client.module.movement.Fly;
import dev.ghost.client.module.movement.NoFall;
import dev.ghost.client.module.movement.Speed;
import dev.ghost.client.module.render.ESP;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ModuleManager {

    private final List<Module> modules = new ArrayList<>();

    public void registerAll() {
        modules.add(new KillAura());
        modules.add(new AntiKB());
        modules.add(new Fly());
        modules.add(new Speed());
        modules.add(new NoFall());
        modules.add(new ESP());
        modules.add(new Timer());
        modules.add(new ResetVL());
    }

    public void onTick() {
        for (Module m : modules) {
            if (m.isEnabled()) m.onTick();
        }
    }

    public List<Module> getModules() {
        return Collections.unmodifiableList(modules);
    }

    @SuppressWarnings("unchecked")
    public <T extends Module> T getModule(Class<T> clazz) {
        return (T) modules.stream()
                          .filter(m -> m.getClass() == clazz)
                          .findFirst().orElse(null);
    }
}
