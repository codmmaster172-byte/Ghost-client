// language: Java 21  file: GhostClient.java  target: Fabric 1.21.4
// Client entry point.  Registers:
//   ClientTickEvents   → module tick + edge-triggered keybind handler
//   WorldRenderEvents  → ESP world render
//   Key: RSHIFT        → open ClickGUI
package dev.ghost.client;

import dev.ghost.client.gui.ClickGUI;
import dev.ghost.client.manager.ModuleManager;
import dev.ghost.client.module.Module;
import dev.ghost.client.module.render.ESP;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Map;

public class GhostClient implements ClientModInitializer {

    public static ModuleManager moduleManager;
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    // Edge-detection: key was NOT down last tick
    private final Map<Integer, Boolean> prevKeys = new HashMap<>();

    @Override
    public void onInitializeClient() {
        moduleManager = new ModuleManager();
        moduleManager.registerAll();

        // ── Tick ──────────────────────────────────────────────────────────
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null) return;

            // Module ticks
            moduleManager.onTick();

            // Keybind scan — edge-triggered (rising-edge only)
            scanKeys(client);
        });

        // ── World render — ESP ────────────────────────────────────────────
        WorldRenderEvents.AFTER_ENTITIES.register(ctx -> {
            ESP esp = moduleManager.getModule(ESP.class);
            if (esp != null) esp.renderWorld(ctx);
        });
    }

    private void scanKeys(MinecraftClient client) {
        // RSHIFT → ClickGUI
        if (risingEdge(GLFW.GLFW_KEY_RIGHT_SHIFT)) {
            if (client.currentScreen == null) {
                client.execute(() -> client.setScreen(new ClickGUI()));
            }
        }

        // Per-module keybinds
        for (Module mod : moduleManager.getModules()) {
            int k = mod.getKey();
            if (k != GLFW.GLFW_KEY_UNKNOWN && risingEdge(k)) {
                mod.toggle();
            }
        }
    }

    /** True only on the tick a key transitions from UP → DOWN (no held-key spam). */
    private boolean risingEdge(int key) {
        boolean down = GLFW.glfwGetKey(
            MinecraftClient.getInstance().getWindow().getHandle(), key)
            == GLFW.GLFW_PRESS;
        boolean prev = prevKeys.getOrDefault(key, false);
        prevKeys.put(key, down);
        return down && !prev;
    }
}
