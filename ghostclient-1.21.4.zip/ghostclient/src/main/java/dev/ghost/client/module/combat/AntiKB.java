// language: Java 21  file: AntiKB.java
// Reduces horizontal knockback by KEEP_FACTOR each hurt frame.
// 100% cancel flags "AntiKB" on Polar; 15% retention stays under threshold.
package dev.ghost.client.module.combat;

import dev.ghost.client.module.Module;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public class AntiKB extends Module {

    private static final double KEEP = 0.15; // fraction of knockback to retain

    public AntiKB() {
        super("AntiKB", Category.COMBAT, GLFW.GLFW_KEY_UNKNOWN, "Reduce knockback");
    }

    @Override
    public void onTick() {
        if (!nullCheck()) return;
        if (mc.player.hurtTime <= 0) return;

        Vec3d v = mc.player.getVelocity();
        mc.player.setVelocity(v.x * KEEP, v.y, v.z * KEEP);
    }
}
