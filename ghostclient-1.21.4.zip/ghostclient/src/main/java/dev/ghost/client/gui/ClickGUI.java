// language: Java 21  file: ClickGUI.java  target: Fabric 1.21.4
// DrawContext-based ClickGUI.  Open with RSHIFT.
// One panel per category.  Click module name to toggle.  ESC or RSHIFT closes.
package dev.ghost.client.gui;

import dev.ghost.client.GhostClient;
import dev.ghost.client.module.Module;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.*;

public class ClickGUI extends Screen {

    private static final int PANEL_W    = 100;
    private static final int ROW_H      = 14;
    private static final int HEADER_H   = 14;
    private static final int PAD        = 4;
    private static final int GAP        = 6;  // pixels between panels

    // Panel drag state
    private final Map<Module.Category, int[]> positions = new HashMap<>();
    private Module.Category dragging      = null;
    private int dragOffX, dragOffY;

    public ClickGUI() {
        super(Text.literal("Ghost"));
        // Default panel positions — one column per category
        int x = 10;
        for (Module.Category cat : Module.Category.values()) {
            positions.put(cat, new int[]{x, 10});
            x += PANEL_W + GAP;
        }
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        // Dark transparent overlay
        ctx.fill(0, 0, width, height, 0x88000000);

        for (Module.Category cat : Module.Category.values()) {
            int[] pos  = positions.get(cat);
            int   x    = pos[0], y = pos[1];
            List<Module> mods = getModulesFor(cat);
            int panelH = HEADER_H + mods.size() * ROW_H + PAD;

            // Panel background
            ctx.fill(x, y, x + PANEL_W, y + panelH, 0xCC1a1a2e);
            // Header bar
            ctx.fill(x, y, x + PANEL_W, y + HEADER_H, 0xFF16213e);
            ctx.drawTextWithShadow(textRenderer,
                cat.name(), x + PAD, y + 3, 0xFF00FFFF);

            // Modules
            int ry = y + HEADER_H;
            for (Module mod : mods) {
                boolean hovered = mx >= x && mx <= x + PANEL_W &&
                                  my >= ry && my <= ry + ROW_H;
                int rowBg = hovered ? 0x99223355 : 0x00000000;
                ctx.fill(x, ry, x + PANEL_W, ry + ROW_H, rowBg);

                int color = mod.isEnabled() ? 0xFF00FF88 : 0xFFAAAAAA;
                ctx.drawTextWithShadow(textRenderer, mod.getName(),
                    x + PAD, ry + 3, color);

                // Bind label (right-aligned)
                if (mod.getKey() != org.lwjgl.glfw.GLFW.GLFW_KEY_UNKNOWN) {
                    String bind = org.lwjgl.glfw.GLFW.glfwGetKeyName(mod.getKey(), 0);
                    if (bind != null) {
                        int bw = textRenderer.getWidth("[" + bind.toUpperCase() + "]");
                        ctx.drawTextWithShadow(textRenderer,
                            "[" + bind.toUpperCase() + "]",
                            x + PANEL_W - bw - 2, ry + 3, 0xFF666666);
                    }
                }
                ry += ROW_H;
            }
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        for (Module.Category cat : Module.Category.values()) {
            int[] pos  = positions.get(cat);
            int   x    = pos[0], y = pos[1];
            List<Module> mods = getModulesFor(cat);
            int panelH = HEADER_H + mods.size() * ROW_H + PAD;

            if (mx >= x && mx <= x + PANEL_W && my >= y && my <= y + panelH) {
                if (button == 0) { // left click
                    if (my < y + HEADER_H) {
                        // Start drag
                        dragging = cat;
                        dragOffX = (int)(mx - x);
                        dragOffY = (int)(my - y);
                        return true;
                    }
                    // Toggle module
                    int idx = (int)((my - y - HEADER_H) / ROW_H);
                    if (idx >= 0 && idx < mods.size()) {
                        mods.get(idx).toggle();
                        return true;
                    }
                }
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int btn, double dx, double dy) {
        if (dragging != null) {
            int[] pos = positions.get(dragging);
            pos[0] = (int)(mx - dragOffX);
            pos[1] = (int)(my - dragOffY);
            return true;
        }
        return super.mouseDragged(mx, my, btn, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int btn) {
        dragging = null;
        return super.mouseReleased(mx, my, btn);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT_SHIFT ||
            key == org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE) {
            this.close();
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    private List<Module> getModulesFor(Module.Category cat) {
        List<Module> out = new ArrayList<>();
        for (Module m : GhostClient.moduleManager.getModules()) {
            if (m.getCategory() == cat) out.add(m);
        }
        return out;
    }
}
