// language: Java 21  file: RotationUtil.java
// GCD mouse-fix: Polar checks that yaw/pitch deltas align with real mouse
// sensitivity quanta.  Rotations that don't land on the grid fire "InvalidRotation".
// Smooth rotation: snap-aim (instant angle change) fires "RotationSpeed".
package dev.ghost.client.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class RotationUtil {

    private RotationUtil() {}

    private static final MinecraftClient mc = MinecraftClient.getInstance();

    // ── GCD ──────────────────────────────────────────────────────────────────

    /** Mouse sensitivity quantum matching Minecraft's MouseSettings formula. */
    public static double computeGCD() {
        double sens = mc.options.getMouseSensitivity().getValue(); // 0.0–1.0
        double f    = sens * 0.6 + 0.2;
        return f * f * f * 1.2;
    }

    /** Snap rotation delta to nearest mouse-grid multiple, then clamp pitch. */
    public static float[] gcdFix(float targetYaw, float targetPitch,
                                  float currentYaw, float currentPitch) {
        double gcd = computeGCD();
        if (gcd <= 0) return new float[]{targetYaw, targetPitch};

        double dYaw   = targetYaw   - currentYaw;
        double dPitch = targetPitch - currentPitch;

        dYaw   = Math.round(dYaw   / gcd) * gcd;
        dPitch = Math.round(dPitch / gcd) * gcd;

        return new float[]{
            (float)(currentYaw   + dYaw),
            MathHelper.clamp((float)(currentPitch + dPitch), -90f, 90f)
        };
    }

    // ── Smooth ───────────────────────────────────────────────────────────────

    /** Move toward target by at most `speed` deg/tick, then GCD-fix. */
    public static float[] smoothRotation(float curYaw,   float curPitch,
                                          float tgtYaw,   float tgtPitch,
                                          float speed) {
        float dYaw   = wrapDegrees(tgtYaw   - curYaw);
        float dPitch = wrapDegrees(tgtPitch - curPitch);

        float sYaw   = MathHelper.clamp(dYaw,   -speed, speed);
        float sPitch = MathHelper.clamp(dPitch, -speed, speed);

        return gcdFix(curYaw + sYaw, curPitch + sPitch, curYaw, curPitch);
    }

    // ── Angle to entity ──────────────────────────────────────────────────────

    /** Ideal [yaw, pitch] to face the given entity's eye position. */
    public static float[] getRotationsTo(Entity target) {
        Vec3d playerEyes = mc.player.getEyePos();
        Vec3d targetEyes = target.getEyePos();

        double dx   = targetEyes.x - playerEyes.x;
        double dy   = targetEyes.y - playerEyes.y;
        double dz   = targetEyes.z - playerEyes.z;
        double dist = Math.sqrt(dx * dx + dz * dz);

        float yaw   = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90f;
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, dist));

        return new float[]{yaw, pitch};
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    public static float wrapDegrees(float d) {
        d %= 360f;
        if (d >= 180f)  d -= 360f;
        if (d < -180f)  d += 360f;
        return d;
    }

    public static float getYawDiff(float a, float b) {
        return Math.abs(wrapDegrees(a - b));
    }
}
