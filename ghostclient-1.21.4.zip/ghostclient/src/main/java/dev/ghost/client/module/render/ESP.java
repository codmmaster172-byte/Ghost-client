// language: Java 21  file: ESP.java
// Renders wireframe boxes around players using WorldRenderContext.
// Registered via WorldRenderEvents.AFTER_ENTITIES in GhostClient.
// Pure client-side — server sees nothing, no bypass needed.
package dev.ghost.client.module.render;

import dev.ghost.client.module.Module;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.lwjgl.glfw.GLFW;

public class ESP extends Module {

    public ESP() {
        super("ESP", Category.RENDER, GLFW.GLFW_KEY_UNKNOWN, "Player boxes through walls");
    }

    /** Called from WorldRenderEvents.AFTER_ENTITIES registered in GhostClient. */
    public void renderWorld(WorldRenderContext ctx) {
        if (!isEnabled() || !nullCheck()) return;

        MatrixStack matrices = ctx.matrixStack();
        Camera camera        = ctx.camera();
        Vec3d  camPos        = camera.getPos();

        VertexConsumerProvider.Immediate provider =
            mc.getRenderManager().getBuffers().getEntityVertexConsumers();
        VertexConsumer lines = provider.getBuffer(RenderLayer.getLines());

        matrices.push();
        matrices.translate(-camPos.x, -camPos.y, -camPos.z);

        for (PlayerEntity player : mc.world.getPlayers()) {
            if (player == mc.player) continue;
            if (!player.isAlive())   continue;

            float pt  = ctx.tickCounter().getTickDelta(false);
            double rx = player.prevX + (player.getX() - player.prevX) * pt;
            double ry = player.prevY + (player.getY() - player.prevY) * pt;
            double rz = player.prevZ + (player.getZ() - player.prevZ) * pt;

            Box bb     = player.getBoundingBox();
            double w   = (bb.maxX - bb.minX) / 2.0;
            double h   = bb.maxY - bb.minY;

            Box render = new Box(rx - w, ry, rz - w, rx + w, ry + h, rz + w);
            Matrix4f mat = matrices.peek().getPositionMatrix();

            // Cyan outline — draw 12 edges manually for a clean wireframe
            drawBox(lines, mat, render, 0f, 1f, 1f, 0.8f);
        }

        matrices.pop();
    }

    // ── Draw all 12 edges of an AABB ──────────────────────────────────────────

    private void drawBox(VertexConsumer buf, Matrix4f mat, Box b,
                         float r, float g, float bl, float a) {
        float x0 = (float) b.minX, y0 = (float) b.minY, z0 = (float) b.minZ;
        float x1 = (float) b.maxX, y1 = (float) b.maxY, z1 = (float) b.maxZ;

        // Bottom face
        line(buf, mat, x0,y0,z0, x1,y0,z0, r,g,bl,a);
        line(buf, mat, x1,y0,z0, x1,y0,z1, r,g,bl,a);
        line(buf, mat, x1,y0,z1, x0,y0,z1, r,g,bl,a);
        line(buf, mat, x0,y0,z1, x0,y0,z0, r,g,bl,a);
        // Top face
        line(buf, mat, x0,y1,z0, x1,y1,z0, r,g,bl,a);
        line(buf, mat, x1,y1,z0, x1,y1,z1, r,g,bl,a);
        line(buf, mat, x1,y1,z1, x0,y1,z1, r,g,bl,a);
        line(buf, mat, x0,y1,z1, x0,y1,z0, r,g,bl,a);
        // Verticals
        line(buf, mat, x0,y0,z0, x0,y1,z0, r,g,bl,a);
        line(buf, mat, x1,y0,z0, x1,y1,z0, r,g,bl,a);
        line(buf, mat, x1,y0,z1, x1,y1,z1, r,g,bl,a);
        line(buf, mat, x0,y0,z1, x0,y1,z1, r,g,bl,a);
    }

    private void line(VertexConsumer buf, Matrix4f mat,
                      float x0,float y0,float z0,
                      float x1,float y1,float z1,
                      float r,float g,float b,float a) {
        float nx = x1 - x0, ny = y1 - y0, nz = z1 - z0;
        float len = (float) Math.sqrt(nx*nx + ny*ny + nz*nz);
        if (len == 0) return;
        buf.vertex(mat, x0, y0, z0).color(r,g,b,a).normal(nx/len, ny/len, nz/len);
        buf.vertex(mat, x1, y1, z1).color(r,g,b,a).normal(nx/len, ny/len, nz/len);
    }
}
