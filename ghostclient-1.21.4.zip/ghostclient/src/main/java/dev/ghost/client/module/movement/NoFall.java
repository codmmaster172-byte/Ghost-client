// language: Java 21  file: NoFall.java
// One tick before landing, send onGround=true — resets server fallDistance
// before the actual landing packet so no damage is applied.
package dev.ghost.client.module.movement;

import dev.ghost.client.module.Module;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import org.lwjgl.glfw.GLFW;

public class NoFall extends Module {

    private static final float THRESHOLD = 2.5f;
    private boolean sent = false;

    public NoFall() {
        super("NoFall", Category.MOVEMENT, GLFW.GLFW_KEY_UNKNOWN, "Cancel fall damage");
    }

    @Override
    public void onTick() {
        if (!nullCheck()) return;

        if (mc.player.fallDistance >= THRESHOLD && !sent) {
            mc.getNetworkHandler().sendPacket(
                new PlayerMoveC2SPacket.OnGroundOnly(true));
            sent = true;
        }

        if (mc.player.getVelocity().y > 0 || mc.player.isOnGround()) {
            sent = false;
        }
    }
}
