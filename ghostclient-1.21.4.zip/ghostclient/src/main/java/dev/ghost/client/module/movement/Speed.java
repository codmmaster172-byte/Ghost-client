// language: Java 21  file: Speed.java
// Bunny-hop: jump every landing.  Each individual air-tick packet stays under
// Polar's per-tick cap (~0.49 b/t for sprinting).  Noise jitter breaks the
// identical-delta pattern matcher.
package dev.ghost.client.module.movement;

import dev.ghost.client.module.Module;
import dev.ghost.client.util.MovementUtil;
import org.lwjgl.glfw.GLFW;

public class Speed extends Module {

    public static double SPEED = 0.44;  // b/t — just under Polar's 0.49 cap

    public Speed() {
        super("Speed", Category.MOVEMENT, GLFW.GLFW_KEY_V, "Bunny-hop speed bypass");
    }

    @Override
    public void onDisable() {
        if (!nullCheck()) return;
        mc.player.setVelocity(
            mc.player.getVelocity().x * 0.1,
            mc.player.getVelocity().y,
            mc.player.getVelocity().z * 0.1);
    }

    @Override
    public void onTick() {
        if (!nullCheck()) return;
        if (!MovementUtil.isMoving()) return;

        if (mc.player.isOnGround()) {
            mc.player.jump();
        }

        if (!mc.player.isOnGround()) {
            MovementUtil.setSpeed(SPEED);
            // ±0.006 noise — breaks Polar's identical-packet pattern detector
            double n = (Math.random() - 0.5) * 0.012;
            mc.player.setVelocity(
                mc.player.getVelocity().x + n,
                mc.player.getVelocity().y,
                mc.player.getVelocity().z + n);
        }
    }
}
