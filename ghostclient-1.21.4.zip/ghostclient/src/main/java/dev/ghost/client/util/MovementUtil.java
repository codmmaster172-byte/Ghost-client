// language: Java 21  file: MovementUtil.java
package dev.ghost.client.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class MovementUtil {

    private MovementUtil() {}

    private static final MinecraftClient mc = MinecraftClient.getInstance();

    public static boolean isMoving() {
        return mc.player.input.movementForward != 0 ||
               mc.player.input.movementSideways != 0;
    }

    /** Push horizontal velocity to `speed` in the direction the player is pressing. */
    public static void setSpeed(double speed) {
        if (!isMoving()) return;

        float yaw = mc.player.getYaw();
        float fwd = mc.player.input.movementForward;
        float str = mc.player.input.movementSideways;

        double len = Math.sqrt(fwd * fwd + str * str);
        if (len == 0) return;
        fwd /= len; str /= len;

        double rad = Math.toRadians(yaw);
        double vx  = -MathHelper.sin((float) rad) * fwd * speed
                   +  MathHelper.cos((float) rad) * str * speed;
        double vz  =  MathHelper.cos((float) rad) * fwd * speed
                   +  MathHelper.sin((float) rad) * str * speed;

        mc.player.setVelocity(vx, mc.player.getVelocity().y, vz);
    }

    public static double getHorizSpeed() {
        Vec3d v = mc.player.getVelocity();
        return Math.sqrt(v.x * v.x + v.z * v.z);
    }
}
