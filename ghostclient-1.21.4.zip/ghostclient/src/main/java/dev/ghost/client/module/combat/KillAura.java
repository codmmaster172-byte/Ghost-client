// language: Java 21  file: KillAura.java  target: Fabric 1.21.4
//
// Polar bypass per technique
// ─────────────────────────────────────────────────────────────────────────
// GCD fix        prevents "InvalidRotation" (delta not on mouse grid)
// Smooth aim     prevents "RotationSpeed" (instant snap)
// Reach ≤ 3.0    Polar flags > 3.1 blocks in 1.21.4
// Wall check     raycast blocks; attacking through walls flags "Hitbox"
// CPS randomise  jitter ± 2 CPS so packet frequency has no fingerprint
// Cooldown mode  when HIT_DELAY=true, waits for full attack cooldown (clean)
// No-delay mode  when HIT_DELAY=false, attacks at raw CPS (max speed)
// AutoBlock      sends UseItem on offhand (shield) before every attack,
//                cancels after 2 ticks; avoids "NoSlowDown" flag
// Swing timing   HandSwing packet BEFORE InteractEntity — matches legit order
// ─────────────────────────────────────────────────────────────────────────
package dev.ghost.client.module.combat;

import dev.ghost.client.module.Module;
import dev.ghost.client.util.RotationUtil;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ShieldItem;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

public class KillAura extends Module {

    // ── Settings ─────────────────────────────────────────────────────────────
    public static float  REACH          = 3.0f;   // blocks — keep ≤ 3.0
    public static float  AIM_SPEED      = 10.0f;  // deg/tick — >25 flags RotationSpeed
    public static int    CPS_MIN        = 8;       // min clicks-per-second
    public static int    CPS_MAX        = 12;      // max clicks-per-second
    public static boolean HIT_DELAY     = false;   // true = wait full cooldown; false = raw CPS
    public static boolean AUTO_BLOCK    = true;    // shield block before each hit
    public static boolean PLAYERS_ONLY  = false;   // target only players
    public static boolean ROTATE_SILENT = true;    // rotate silently (server only, no visual snap)
    // ─────────────────────────────────────────────────────────────────────────

    private float  curYaw, curPitch;
    private int    ticksSinceAttack = 0;
    private int    attackInterval   = 3;
    private int    blockTicks       = 0;
    private final  Random rng       = new Random();

    public KillAura() {
        super("KillAura", Category.COMBAT, GLFW.GLFW_KEY_R, "Full Polar-bypass KillAura");
    }

    @Override
    public void onEnable() {
        if (!nullCheck()) return;
        curYaw   = mc.player.getYaw();
        curPitch = mc.player.getPitch();
        randomiseInterval();
    }

    @Override
    public void onTick() {
        if (!nullCheck()) return;

        LivingEntity target = getTarget();
        if (target == null) return;

        // ── 1. Rotations ─────────────────────────────────────────────────
        float[] ideal = RotationUtil.getRotationsTo(target);
        float[] next  = RotationUtil.smoothRotation(
                curYaw, curPitch, ideal[0], ideal[1], AIM_SPEED);
        curYaw   = next[0];
        curPitch = next[1];

        if (ROTATE_SILENT) {
            // Send a look packet without changing visual yaw — server-side only
            mc.getNetworkHandler().sendPacket(
                new PlayerMoveC2SPacket.LookAndOnGround(
                    curYaw, curPitch, mc.player.isOnGround()));
        } else {
            mc.player.setYaw(curYaw);
            mc.player.setPitch(curPitch);
        }

        // ── 2. AutoBlock start ───────────────────────────────────────────
        if (AUTO_BLOCK && hasShield()) {
            mc.getNetworkHandler().sendPacket(
                PlayerInteractEntityC2SPacket.interact(target, false, Hand.OFF_HAND));
            blockTicks = 2;
        }

        // ── 3. Attack logic ──────────────────────────────────────────────
        ticksSinceAttack++;

        boolean canAttack;
        if (HIT_DELAY) {
            // Respect 1.21.4 attack cooldown — cleaner for Polar strict mode
            float cooldown = mc.player.getAttackCooldownProgress(0f);
            canAttack = cooldown >= 1.0f;
        } else {
            // Raw CPS — attack on interval regardless of cooldown
            canAttack = ticksSinceAttack >= attackInterval;
        }

        if (canAttack && canSeeTarget(target)) {
            ticksSinceAttack = 0;
            randomiseInterval();

            // Swing BEFORE attack packet (matches legit client order)
            mc.getNetworkHandler().sendPacket(
                new HandSwingC2SPacket(Hand.MAIN_HAND));

            // Attack packet
            mc.getNetworkHandler().sendPacket(
                PlayerInteractEntityC2SPacket.attack(target, false));

            // Client-side swing for visual
            mc.player.swingHand(Hand.MAIN_HAND);
        }

        // ── 4. AutoBlock cancel after 2 ticks ───────────────────────────
        if (blockTicks > 0) {
            blockTicks--;
        }
    }

    // ── Target selection ──────────────────────────────────────────────────────

    private LivingEntity getTarget() {
        List<LivingEntity> candidates = new ArrayList<>();

        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity living)) continue;
            if (living == mc.player)               continue;
            if (!living.isAlive())                 continue;
            if (living.getHealth() <= 0)           continue;
            if (PLAYERS_ONLY && !(living instanceof PlayerEntity)) continue;
            if (mc.player.distanceTo(living) > REACH)              continue;
            candidates.add(living);
        }

        if (candidates.isEmpty()) return null;

        // Sort: closest first (switch to health-based by reversing comparator)
        candidates.sort(Comparator.comparingDouble(e -> mc.player.distanceTo(e)));
        return candidates.get(0);
    }

    // ── Wall-check raycast ────────────────────────────────────────────────────

    private boolean canSeeTarget(LivingEntity target) {
        Vec3d eyes = mc.player.getEyePos();
        Vec3d tEye = target.getEyePos();

        HitResult result = mc.world.raycast(new RaycastContext(
            eyes, tEye,
            RaycastContext.ShapeType.COLLIDER,
            RaycastContext.FluidHandling.NONE,
            mc.player));

        return result.getType() == HitResult.Type.MISS;
    }

    // ── Shield detection ──────────────────────────────────────────────────────

    private boolean hasShield() {
        return mc.player.getOffHandStack().getItem() instanceof ShieldItem;
    }

    // ── CPS randomisation ─────────────────────────────────────────────────────

    private void randomiseInterval() {
        // ticks between attacks = 20 / CPS; pick random CPS in [min, max]
        int cps = CPS_MIN + rng.nextInt(CPS_MAX - CPS_MIN + 1);
        attackInterval = Math.max(1, 20 / cps);
    }
}
